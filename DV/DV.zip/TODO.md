# TODO
1. Update project saves
2. Improve multithreading
3. Finish documentation
4. Creates separate window for analytics
5. Create more than 1 projection line
6. Substitute linear function by a weighted sum of functions

# Wish List
1. Figure out how to visually separate very vertical visualizations (BCI and Satimage datasets)
